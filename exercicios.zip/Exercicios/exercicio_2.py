"""
A primeira proposta aqui é a seguinte faça um programa que peça ao usuário para digitar um número inteiro.
Informe se este número par ou ímpar certo.
E caso o usuário digite um caso o usuário não digite o número inteiro informe que o número não é um
inteiro.
"""

import re

def is_int(val):
    if isinstance(val, int): return True
    if re.search(r'^\-{,1}[0-9]+$', val): return True

numero = input('Digite um número inteiro: ')

if numero.isnumeric():
    numero = int(numero)
    if is_int(numero):
        if numero % 2 == 0:
            print(f'{numero} é par')
        else:
            print(f'{numero} é impar')
else:
    print(f'Numero {numero} não é inteiro')
