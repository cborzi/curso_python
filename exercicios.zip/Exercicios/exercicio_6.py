
texto = 'Carlos'
print(texto[2:4])
print(texto[-1])
print(texto[:3])
print(texto[3:])
print(texto[::2]) # pula de 2 em 2

for letra in texto:
    print(letra)
