def mod11(numero):
    tam = len(numero)
    tam += 1
    soma = 0
    ind = 0
    for fator in range(tam,1,-1):
        soma += (int(numero[ind]) * fator)
        ind += 1

    calc = 11 - (soma % 11 )
    if calc > 9:
        return 0
    else:
        return calc

######## PRINCIPAL
cpf = '023.377.028'

new_cpf = cpf.replace('.','')

dig = mod11(new_cpf)
new_cpf += str(dig)

dig = mod11(new_cpf)
new_cpf += str(dig)

print(new_cpf)