executar no terminal do pychar pyuic5 design.ui -o design.py

TODA A VEZ QUE ALTERAR O LAYOOUT