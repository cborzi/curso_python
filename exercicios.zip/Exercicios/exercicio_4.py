"""
seguinte faço um programa que peça o primeiro nome do usuário
se o nome tiver 4 letras ou menos escreva seu nome é curto
se tiver entre 5 e 6 letras escreva seu nome é normal
set tiver maior que 6 escreva seu nome é muito grande

"""

nome = input('Entre com o nome do usuário: ')

try:
    tamanho = len(nome)
    if tamanho <= 4:
        print(f'O Nome {nome} é curto')
    elif tamanho >= 5 and tamanho <= 6:
        print(f'O Nome {nome} é normal')
    else:
        print(f'O Nome {nome} é muito grande')
except:
    print('ERRO')