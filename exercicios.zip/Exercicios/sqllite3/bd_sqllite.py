import sqlite3

conexao = sqlite3.connect('basededados.db')
cursor = conexao.cursor()

def criar_db():
    cursor.execute('CREATE TABLE IF NOT EXISTS clientes ('
                   'id INTEGER PRIMARY KEY AUTOINCREMENT,'
                   'nome TEXT,'
                   'peso REAL'
                   ')')

def inserir_db():
    cursor.execute('INSERT INTO clientes (nome, peso) VALUES("Carlos Borzi", 82.5)')

    cursor.execute('INSERT INTO clientes (nome, peso) VALUES (?, ?)', ('Maria', 82))

    cursor.execute('INSERT INTO clientes (nome, peso) VALUES(:nome, :peso)',
               {'nome' : 'Joãozinho', 'peso' : 23}
    )

    cursor.execute('INSERT INTO clientes VALUES(:id, :nome, :peso)',
               {'id' : None , 'nome' : 'Lucas', 'peso' : 33}
    )

    conexao.commit()

def alterar_db():
    cursor.execute('UPDATE clientes SET nome=:nome WHERE id=:id',
                   {'id': 2, 'nome': 'Matilde'}
                   )

    conexao.commit()

def deletar_db():
    cursor.execute('DELETE FROM clientes WHERE id=:id',
                   {'id': 4}
                   )

    conexao.commit()




peso = 50
#cursor.execute('SELECT * FROM clientes')
cursor.execute('SELECT * FROM clientes WHERE peso > :peso',
               {'peso' : peso}
)

for linha in cursor.fetchall():
    ident, nome, peso = linha
    print(ident, nome, peso)



cursor.close()
conexao.close()
