nome = input('Entre com o nome do usuário: ')
senha = input('Entre com a Senha: ')

try:
    if len(nome) == 0 or len(senha) == 0:
        print('Nome ou Senha em branco!!!')
    else:
        print(f'Usuário: {nome} senha {senha}')

    if not nome.isalpha():
        print('Nome invalido, a caracteres invalidos!!!')
except:
    print('ERRO')