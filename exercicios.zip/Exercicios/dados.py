produtos = [
    {'nome': 'p1', 'preco': 13},
    {'nome': 'p2', 'preco': 55.5},
    {'nome': 'p3', 'preco': 5.59},
    {'nome': 'p4', 'preco': 22},
    {'nome': 'p5', 'preco': 133},
    {'nome': 'p6', 'preco': 1},
    {'nome': 'p7', 'preco': 13.33},
    {'nome': 'p8', 'preco': 12},
    {'nome': 'p9', 'preco': 43},
    {'nome': 'p10', 'preco': 12.99},
]

pessoas = [
    {'nome': 'Carlos', 'idade': 54},
    {'nome': 'Matilde', 'idade': 51},
    {'nome': 'Lucas', 'idade': 6},
    {'nome': 'Maria', 'idade': 74},
    {'nome': 'Rose', 'idade': 51},
    {'nome': 'Malu', 'idade': 53},
    {'nome': 'Marco', 'idade': 53},
    {'nome': 'Mario', 'idade': 55},
    {'nome': 'Davi', 'idade': 6},
]

lista = [1,2,3,4,5,6,7,8,9,10]
