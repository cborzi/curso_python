"""
A segunda proposta que eu faço é um programa que pergunte a hora ao usuário baseando se no horário descrito
exibe a saudação apropriada a exemplo de 
0 aos 11 Bom dia 
12 às 17 Boa tarde
18 23 Boa noite.
"""

horas = input('Entre um horário 0-23: ')

if horas.isnumeric():
    horas = int(horas)
    if horas < 0 or horas > 23:
        print(f'Horário deve estar entre 0-23 ')
    else:
        if horas <= 11:
            print('Bom dia')
        elif horas <= 17:
            print('Boa tarde')
        else:
            print('Boa Noite')
else:
    print(f'horário {horas} inválida')
