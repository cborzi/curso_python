"""
Formatando valores com modificadores

:s - Texto (strings)
:d - Inteiros (int)
:f - Números de ponto flutuante (float)
: (CARACTERE) (> OU < OU ^) (QUANTIDADE) (TIPO -s, d ou f)

> - Esquerda
< - Direita
^ - Centro
"""
num_1 = 1
print(f'{num_1:0>10}') # preenche com 0 a esquerda
print(f'{num_1:0<10}') # preenche com 0 a direita
num_2=1150
print(f'{num_2:0<10.2f}') # preenche com 0 a direita e 2 casas decimais

nome='Carlos'
print(f'{nome:#^20}')

nome_formatado = '{:@<40}'.format(nome)
print(nome_formatado)

nome_formatado = '{n:@<40} {n}'.format(n=nome)
print(nome_formatado)

sobrenome='Borzi'
nome_formatado = '{n:Z>20} {s}'.format(n=nome, s=sobrenome)
print(nome_formatado)
