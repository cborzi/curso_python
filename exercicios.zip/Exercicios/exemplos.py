import sys


def exemplos_lambdas():
    a = lambda x, y : x * y
    print(a(2,3))

    lista = [
        ['P1', 13],
        ['P2', 8],
        ['P3', 33],
        ['P4', 23],
        ['P5', 3],
    ]

    print(sorted(lista, key=lambda i: i[1], reverse=True)) # nao altera a lista original

    print(lista)
    lista.sort(key=lambda item: item[1])
    print(lista)

def exemplos_tuplas():
    # tuplas nao sao modificaveis que é diferente das listas que sao modificaveis
    t1 = (1 , 2, 3, 'a' , 'Carlos') # pode ser assim
    t1 = 1 , 2, 3, 'a' , 'Carlos' # ou assim
    #print(type(t1))

    #print(t1)

    #print(t1[4])

    #for v in t1:
    #    print(v)

    #print(t1[2:]) # fatiar

    t1 = 1, # tupla simples
    # print(type(t1))

    t1 = 1,2,3, 'Carlos'
    t2 = 4,5,6
    t3 = t1 + t2
    #print(t3)

    n1, n2, n3, n4, *_, n7 = t3
    #print(n4)

    t1 = (1, 2, 3) * 10
    #print(t1)

    # transformando tupla em lista para alterar valores
    t1 = (1, 2, 3)
    t1 = list(t1)
    t1[2] = 3000
    print(t1)

    t1 = tuple(t1) # voltar a ser tupla
    print(t1)

def dicionarios_python():
    d1 = { 'chave1':'valor chave' }
    d1['nova_chave'] = 'valor nova chave'
    #print(d1)
    #print(d1['chave1'])

    d1 = dict(chave1='valor chave1',
              chave2='valor chave2')
    d1['chave3'] = 'valor chave3'
    #print(d1)
    #if 'chave3' in d1:
    #    print(d1['chave3'])

    #print(d1.get('chave2'))
    #print(d1.get('chave4')) # nao existe
    #if d1.get('chave4') is None:
    #    print('chave4 nao existe')

    d1 = {
        'str' : 'valor',
        123 : 'outro valor',
        (1,2,34) : 'Tupla'
    }
    d1.update({'nova chave' : 'novo valor'})
    #print(d1)
    #del d1['str']
    #print(d1)

    #print('str' in d1)
    #print('str' in d1.keys())
    #print('Tupla' in d1.values())
    #print(len(d1))

    #for k in d1:
    #    print(k)

    #for v in d1.values():
    #    print(v)

    #for k in d1.items():
     #   print(k)

    #for k,v  in d1.items():
    #    print(k, v)

    clientes = {
        'cliente1' : {
            'nome' : 'Carlos',
            'sobrenome' : 'Borzi',
        },
        'cliente2': {
           'nome': 'Lucas',
           'sobrenome': 'Vieira',
        },
    }

    #for clientes_k, clientes_v in clientes.items():
    #    print(f'Exibindo {clientes_k}')
    #    for dados_k, dados_v in clientes_v.items():
    #        print(f'\t{dados_k}={dados_v}')

    import copy

    d1 = {1: 'a', 2: 'b', 3: 'c', 'd': ['Carlos', 'Lucas']}
    v = d1 # copia raza
    v[1] = 'Carlos'
    v['d'][0] = 'Matilde'
    # veja que alterou nos 2
    #print(d1)
    #print(v)

    # para gera uma novo dicionario
    d1 = {1: 'a', 2: 'b', 3: 'c', 'd': ['Carlos', 'Lucas']}
    v = copy.deepcopy(d1)
    v[1] = 'Carlos'
    v['d'][0] = 'Matilde'
    # veja que alterou nos 2
    #print(d1)
    #print(v)

    lista = [
        ['c1', 1],
        ['c2', 2],
        ['c3', 3],
    ]

    d2 = dict(lista)
    print(lista)
    print(d2)
    #d2.pop('c2') # elimina o item especifico
    d2.popitem() # ultimo item
    print(d2)

    d1.update(d2)
    print(d1)

def set_python():
    s1 = { 1, 2, 3, 4, 5 }
    #for v in s1:
    #    print(v)

    s1 = set()
    s1.add(1)
    s1.add(2)
    s1.add(3)
    #print(s1)
    s1.discard(2)
    #print(s1)
    s1.update([3,4,5]) # nao adiciona elementos duplicados
    #print(s1)

    l1 = [1,1,1,1,1,4,2,2,2,1,1,3,3,3,3,3,4,'Carlos','Carlos']
    s1 = set(l1) # remove os duplicados
    #print(s1)
    l1 = list(s1)
    #print(l1)

    s1 = {1,2,3,4,5,7}
    s2 = {1,2,3,4,5,6}
    s3 = s1 | s2 # uniao
    print(s3)
    s3 = s1 & s2 # interseccao
    print(s3)
    s3 = s1 - s2 # somente elementos do s1
    print(s3)
    s3 = s2 - s1 # somente elementos do s2
    print(s3)
    s3 = s1 ^ s2 # somente os diferentes que estao nos dois
    print(s3)

def comprehension_python():
    l1  = [1,2,3,4,5,6,7,8,9]
    ex1 = [variavel for variavel in l1]
    ex2 = [v * 2 for v in l1]
    ex3 = [(v,v2) for v in l1 for v2 in range(3)]

    l2  = ['Carlos', 'Lucas', 'Matilde']
    ex4 = [v.replace('a', '@').upper() for v in l2]

    tupla = (
        {'chave', 'valor' },
        { 'chave2', 'valor2'},
    )
    ex5 = [(y,x) for x,y in tupla]
    ex5 = dict(ex5)

    l3 = list(range(100))
    ex6 = [v for v in l3 if v % 2 == 0]
    ex6 = [v for v in l3 if v % 3 == 0 if v % 8 == 0]

    ex7 = [v if v % 3 == 0 else 0 for v in l3]


    # exercicio proposto
    string = '01234567890123456789012345678901234567890123456789'
    n = 10
    lista = [string[i: i + n] for i in range(0, len(string), n)]
    retorno = '.'.join(lista)
    print(lista)
    print(retorno)

def dict_comprehension_python():
    lista = [
        { 'chave', 'valor' },
        { 'chave2', 'valor2' },
    ]
    # fazem a mesma coisa
    d1 = { x: y for x,y in lista}
    d1 = dict(lista)
    print(d1)

def objetos_iteraveis():
    #iteraveis
    lista = [0,1,2,3,4,5]
    lista = 'String'
    #print(hasattr(lista,'__iter__'))
    #nao iteraveis
    lista = 12244
    #print(hasattr(lista,'__iter__'))

    lista = [0,1,2,3,4,5]
    lista = iter(lista)
    #print(next(lista))
    #print(next(lista))
    #print(next(lista))
    #print(next(lista))

    #print(hasattr(lista, '__next__'))

    import sys
    import time
    lista = list(range(1000))
    #print(sys.getsizeof(lista))

    def geral():
        v = 'Valor1'
        yield v
        v = 'Valor2'
        yield v
        v = 'Valor3'
        yield v

    g = geral()

    #print(g)
    #print(next(g))
    #print(next(g))
    #print(next(g))

    #for v in g:
    #    print(v)

    #lista
    lista = [x for x in range(1000) ]
    print(type(lista))
    #gerador
    lista = (x for x in range(1000))
    print(type(lista))

def iterador_python():
    nome = 'Carlos Borzi'
    iterador = iter(nome)
    gerador = ( letra for letra  in nome)

    '''
    try:
       print(next(iterador)) # C
       print(next(iterador)) # a
       print(next(iterador)) # r
       print(next(iterador)) # l
       print(next(iterador)) # o
       print(next(iterador)) # s

       print(next(iterador)) # espaco

       print(next(iterador)) # B
       print(next(iterador)) # o
       #print(next(iterador)) # r
       #print(next(iterador)) # z
       #print(next(iterador)) # i

       #print(next(iterador)) # gera execption
    except:
        pass

    print('CADE OS VALORES')
    for v in iterador:
        print(v)
    '''

    print(next(gerador))
    print(next(gerador))
    print(next(gerador))
    print(next(gerador))

    print('olha o FOR')
    for letra in gerador:
        print(letra)

    print('olha o outro FOR')
    for letra in gerador:
        print(letra)

def exercicio_proposto_57():
    carrinho = []
    carrinho.append(('Produto1', 30))
    carrinho.append(('Produto2', 20))
    carrinho.append(('Produto3', 50))

    # Codigo comum nao eficiente
    #total = 0
    #for produto in carrinho:
    #    total += produto[1]
    #print(total)

    total = sum([v for p,v in carrinho ])
    print(total)

def exercicio_de_python_somando_duas_listas():
    """
    Considerando duas listas de inteiros ou floats (lista A e lista B)
    Some os valores nas listas retornando uma nova lista com os valores somados:
    Se uma lista for maior que a outra, a soma só vai considerar o tamanho da
    menor.
    Exemplo:
    lista_a     = [1, 2, 3, 4, 5, 6, 7]
    lista_b     = [1, 2, 3, 4]
    =================== resultado
    lista_soma  = [2, 4, 6, 8]
    """
    lista_a = [10, 2, 3, 40, 5, 6, 7]
    lista_b = [1, 2, 3, 4]
    lista_soma = [x + y for x, y in zip(lista_a, lista_b)]
    print(lista_soma)

    # lista_soma = []
    # for i in range(len(lista_b)):
    #     lista_soma.append(lista_a[i] + lista_b[i])
    # print(lista_soma)

    # lista_soma = []
    # for i, _ in enumerate(lista_b):
    #     lista_soma.append(lista_a[i] + lista_b[i])
    # print(lista_soma)


    from itertools import zip_longest

    lista_a = [10, 2, 3, 4, 5]
    lista_b = [12, 2, 3, 6, 50, 60, 70]
    lista_soma = [x + y for x, y in zip_longest(lista_a, lista_b, fillvalue=0)]
    print(lista_soma)  # [22, 4, 6, 10, 55, 60, 70]

def contador_python():
    from itertools import count

    contador = count(start=5, step=2) # contador sem fim

    for valor in contador:
        print(valor)
        if valor >= 10:
            break

def Combinations_Permutations_Product():
    from itertools import combinations, permutations, product

    pessoas = ['Carlos', 'Lucas', 'Matilde', 'Borzi']

    # na combinacao nao duplica
    #for grupo in combinations(pessoas, 2):
    #    print(grupo)

    # combina todos menos (Carlos,Carlos por exemplo)
    #for grupo in permutations(pessoas, 2):
    #    print(grupo)

    # combina todos inclusive (Carlos,Carlos por exemplo)
    for grupo in product(pessoas, repeat=2):
        print(grupo)

def Groupb_Agrupando_valores():
    from itertools import groupby, tee

    alunos = [
        {'nome': 'Carlos', 'nota': 'A'},
        {'nome': 'Lucas', 'nota': 'B'},
        {'nome': 'Matilde', 'nota': 'C'},
        {'nome': 'Maria', 'nota': 'A'},
        {'nome': 'Jose', 'nota': 'B'},
        {'nome': 'Rose', 'nota': 'D'},
        {'nome': 'Marcio', 'nota': 'C'},
        {'nome': 'Marcos', 'nota': 'D'},
        {'nome': 'Davi', 'nota': 'C'},
    ]

    ordena = lambda item: item['nota']
    alunos.sort(key=ordena)
    alunos_agrupados = groupby(alunos,ordena)

    '''
    # Sem tee (com list)
    for agrupamento, valores_agrupados in alunos_agrupados:
        valores = list(valores_agrupados)
        print(f'Agrupamento: {agrupamento}')
        for aluno in valores:
            print(f'\t{aluno}')
        quantidade = len(valores)
        print(f'\t{quantidade} alunos tiraram nota {agrupamento}')
    '''
    # com tee
    for agrupamento, valores_agrupados in alunos_agrupados:
        va1, va2 = tee(valores_agrupados)

        print(f'Agrupamento: {agrupamento}')

        for aluno in va1:
            print(f'\t{aluno}')

        quantidade = len(list(va2))
        print(f'\t{quantidade} alunos tiraram a nota {agrupamento}')
        print()

def mapeamento_python():
    from dados import produtos, pessoas, lista

    # mesmo resultado
    #nova_lista = map(lambda x: x * 2, lista )
    #nova_lista = [x * 2 for x in lista]
    #print(lista)
    #print(list(nova_lista))

    #precos = map(lambda p: p['preco'], produtos)
    #for preco in precos:
    #    print(preco)

    def aumenta_preco(p):
        p['preco'] = round(p['preco'] * 1.05, 2)
        return p

    novos_produtos = map(aumenta_preco,produtos)
    for produto in novos_produtos:
        print(produto)

def filter_python():
    from dados import produtos, pessoas, lista

    # 2 maneiras
    nova_lista = filter(lambda x: x > 5, lista)
    #nova_lista = [x for x in lista if x > 5]
    #print(list(nova_lista))

    #nova_lista = filter(lambda p: p['preco'] > 50, produtos)
    #for produto in nova_lista:
    #    print(produto)

    def filtra(pesssoa):
        if pesssoa['idade'] < 18:
            return True
        else:
            return False

    nova_lista = filter(filtra, pessoas)
    for pessoa in nova_lista:
        print(pessoa)

def reduce_python():
    from dados import produtos, pessoas, lista
    from functools import reduce

    #soma_lista = reduce(lambda ac, i: i + ac, lista, 0)
    #print(soma_lista)

    #soma_precos = reduce(lambda ac, p: p['preco'] * ac, produtos, 0)
    #print(soma_precos)

    soma_idades = reduce(lambda ac, p: ac * p['idade'], pessoas, 0)
    print(soma_idades)

def try_except_raise():
    # https://docs.python.org/3/library/exceptions.html
    def divide(n1, n2):
        try:
            return n1 / n2
        except ZeroDivisionError as error:
            print('Log: ', error)
            raise

    #print(divide(10,0))

    #try:
    #    print(divide(10, 0))
    #except ZeroDivisionError as error:
    #    print('Usuario: ', error)

    def divide1(n1, n2):
        if n2 == 0:
            raise ValueError("n2 nao pode ser 0.")
        return n1 / n2

    try:
        print(divide1(2,0))
    except ValueError as error:
        print('Voce esta tentando dividir por 0.')
        print('Log: ', error)

    if __name__ == '__main__':
        print('Main')

def package_python():
    from vendas.calc_preco import aumento, reducao
    import vendas.formata.preco as preco_real

    preco = 49.99
    preco_com_aumento = aumento(valor=preco, porcentagem=15, formata=True)
    print(preco_com_aumento)

    preco_com_reducao = reducao(valor=preco, porcentagem=15, formata=True)
    print(preco_com_reducao)

    print(preco_real.real(50))

def arquivos_python():
    file = open('abc.txt', '+w')
    file.write('linha1\n')
    file.write('linha2\n')
    file.write('linha3\n')

    file.seek(0,0)
    print('Lendo Linhas')
    print(file.read())
    print('#' * 30)

    file.seek(0,0)
    print(file.readline(), end='')
    print(file.readline(), end='')
    print(file.readline(), end='')
    print('#' * 30)

    file.seek(0, 0)
    print(file.readlines(), end='')
    print()
    print('#' * 30)

    file.seek(0, 0)
    for linha in file.readlines():
        print(linha, end='')

    file.close()

def arquivos_python1():
    with open('abc.txt', '+w') as file:
        file.write('linha1\n')
        file.write('linha2\n')
        file.write('linha3\n')

        file.seek(0,0)
        print('Lendo Linhas')
        print(file.read())
        print('#' * 30)

        # apagar arquivo
        #import os
        #os.remove('abc.txt')

def arquivos_python_jason():
    import json

    d1 = {
        'Pessoa 1': {
            'nome': 'Carlos',
            'idade': 54
        },
        'Pessoa 2': {
            'nome': 'Lucas',
            'idade': 6
        },
    }

    print(d1)
    d1_json = json.dumps(d1, indent=True)
    with open('abc.json', '+w') as file:
        file.write(d1_json)

    print(d1_json)

def arquivos_python_jason_read():
    import json

    with open('abc.json', 'r') as file:
        d1_json = file.read()
        d1_json = json.loads(d1_json)

    for k, v in d1_json.items():
        print(k)
        for k1, v1 in v.items():
            print(k1,v1)

def class_setter_property_python():
    class produto:
        def __init__(self, nome, preco):
            self.nome = nome
            self.preco = preco

        def desconto(self, percentual):
            self.preco = self.preco - (self.preco * (percentual / 100))

        @property
        def nome(self):
            return self._nome

        @nome.setter
        def nome(self, valor):
            self._nome = valor.title()

        # Getter
        @property
        def preco(self):
            return self._preco

        # Setter
        @preco.setter
        def preco(self, valor):
            if isinstance(valor, str):
                valor = float(valor.replace('R$', ''))

            self._preco = valor

    p1 = produto('camiseta', 50)
    p1.desconto(10)
    print(p1.nome, p1.preco)

    p2 = produto('caneca', 'R$60')
    p2.desconto(10)
    print(p2.nome, p2.preco)


def setter_getter_python():
    # SETTER = CONFIGURANDO UM VALOR (=)
    # GETTER = OBTER UM VALOR (.)
    class Pessoa:
        def __init__(self, nome):
            self._nome = nome

        @property
        def nome(self):
            return self._nome

        @nome.setter
        def nome(self, nome):
            self._nome = nome

        @property
        def sobrenome(self):
            return 'DESCONHECIDO'


    p1 = Pessoa('Otávio')
    print(p1.nome)
    print(p1.sobrenome)


def dataclasses_python():
    """
    O que são dataclasses? O módulo Dataclasses fornece um decorador e funções
    para criar automaticamente métodos, como __init__(), __repr__(), __eq__ (etc)
    em classes definidas pelo usuário.
    Basicamente, dataclasses são syntax sugar para criar classes normais.
    Foi originalmente descrito na PEP 557.
    Adicionado na versão 3.7 do Python.
    Leia a documentação: https://docs.python.org/pt-br/3/library/dataclasses.html
    """
    from dataclasses import dataclass
    from dataclasses import field
    from dataclasses import asdict, astuple


    @dataclass(eq=True, repr=True, order=True, frozen=False, init=True)
    class Pessoa:
        nome: str
        sobrenome: str = field(repr=False)

        def __post_init__(self):
            if not isinstance(self.nome, str):
                raise TypeError(
                    f'Invalid type {type(self.nome).__name__} != str em {self}'
                )

        @property
        def nome_completo(self):
            return f'{self.nome} {self.sobrenome}'


    p1 = Pessoa('A', '5')
    p2 = Pessoa('C', '3')
    p3 = Pessoa('D', '4')
    p4 = Pessoa('E', '6')

    pessoas = [p1, p2, p3, p4]

    print(sorted(pessoas, key=lambda pessoa: pessoa.sobrenome, reverse=True))
    print(p1)

    # print(p1)
    # print(p1 == p2)

    # print(p1.nome)
    # print(p1.sobrenome)
    # print(p1.nome_completo)

    print()

    print(asdict(p1))
    print(astuple(p1))


def enum_python():
    from enum import Enum, auto


    class Directions(Enum):
        right = auto()
        left = auto()
        up = auto()
        down = auto()


    def move(direction):
        if not isinstance(direction, Directions):
            raise ValueError('Cannot move in this direction')

        return f'Moving {direction.name}'


    if __name__ == "__main__":
        print(move(Directions.right))
        print(move(Directions.left))
        print(move(Directions.up))
        print(move(Directions.down))

        print()

        for direction in Directions:
            print(direction, direction.value, direction.name)

def minha_lista_em_python():
    class MinhaLista:
        def __init__(self):
            self.__items = []
            self.__index = 0

        def add(self, valor):
            self.__items.append(valor)

        def __getitem__(self, index):
            return self.__items[index]

        def __setitem__(self, index, valor):
            if index >= len(self.__items):
                self.__items.append(valor)
            self.__items[index] = valor

        def __delitem__(self, index):
            del self.__items[index]

        def __iter__(self):
            return self

        def __next__(self):
            try:
                item = self.__items[self.__index]
                self.__index += 1
                return item
            except IndexError:
                raise StopIteration

        def __str__(self):
            return f'{self.__class__.__name__}({self.__items})'

        def __repr__(self):
            return self.__str__()

    if __name__ == "__main__":
        lista = MinhaLista()
        lista.add('Luiz')
        lista.add('Maria')

        # lista = list(lista)

        # print(lista)
        # lista[0] = 'João'
        # lista[2] = 'Funciona?'

        # del lista[2]

        # print(lista)

        for valor in lista:
            print(valor)

        print(lista)





#exemplos_lambdas()
#exemplos_tuplas()
#dicionarios_python()
#set_python()
#comprehension_python()
#dict_comprehension_python()
#objetos_iteraveis()
#iterador_python()
#exercicio_proposto_57()
#exercicio_de_python_somando_duas_listas()
#contador_python()
#Combinations_Permutations_Product()
#Groupb_Agrupando_valores()
#mapeamento_python()
#filter_python()
#reduce_python()
#try_except_raise()
#package_python()
#arquivos_python()
#arquivos_python1()
#arquivos_python_jason()
#arquivos_python_jason_read()
#class_setter_property_python()
#setter_getter_python()
#dataclasses_python()
#enum_python()
minha_lista_em_python()






